export class Student {
    name:string;
    age:number;
    marks:number;
    phone:number;
    email:string;

    
    constructor(
        name:string,
        age:number,
        marks:number,
        phone:number,
        email:string
    )
    {
        this.name = name;
        this.age = age;
        this.marks = marks;
        this.phone = phone;
        this.email = email;
    }
}
