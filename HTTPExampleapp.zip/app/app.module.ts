import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AllStudentsComponent } from './all-students/all-students.component';
import { StudentService } from './student.service';
import { SearchStudentComponent } from './search-student/search-student.component';
import { AddStudentComponent } from './add-student/add-student.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule} from '@angular/common/http';
import { HttpStudentComponent } from './http-student/http-student.component';

@NgModule({
  declarations: [
    AppComponent,
    AllStudentsComponent,
    SearchStudentComponent,
    AddStudentComponent,
    HttpStudentComponent
  ],
  imports: [
    FormsModule,
    BrowserModule,
    HttpClientModule
  ],
  providers: [StudentService],
  bootstrap: [AppComponent]
})
export class AppModule { }
