import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { Student } from '../student';

@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css']
})
export class AddStudentComponent implements OnInit {

  studentModel:Student = new Student('',0,0,0,'');
  constructor() { }




  ngOnInit() {
  }

  addStudent()
  {
    console.log(this.studentModel);
  }



}
