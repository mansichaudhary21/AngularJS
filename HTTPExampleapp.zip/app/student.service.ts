import { Injectable } from '@angular/core';
import { Student } from './student';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  students:Array<Student> = [];
  private endpoint = "/assets/data/Student.json";//

  constructor(private http:HttpClient) {

    let stu1 = new Student("ramesh",10,200,9654144814,"ramesh@gmail.com");
    this.students.push(stu1);
    let stu2 = new Student("ram",10,200,9654144814,"ramesh@gmail.com");
    this.students.push(stu2);
    let stu3 = new Student("suresh",10,200,9654144814,"ramesh@gmail.com");
    this.students.push(stu3);
   }


   getStudentsFromServer():Observable<StudentService[]>
   {
    return this.http.get<StudentService[]>(this.endpoint);
   }

   getStudentArray()
   {
     return this.students;
   }

   getStudentByName(name:string)
   {
     let isFound:boolean = false;
     for(let student of this.students)
     {
       if(student.name.includes(name))
       {
          console.log(" --> Service "+student.name);
         //return true;
       }
     }
     return isFound;
   }

}
