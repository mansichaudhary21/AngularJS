import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HttpStudentComponent } from './http-student.component';

describe('HttpStudentComponent', () => {
  let component: HttpStudentComponent;
  let fixture: ComponentFixture<HttpStudentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HttpStudentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HttpStudentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
