import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-http-student',
  templateUrl: './http-student.component.html',
  styleUrls: ['./http-student.component.css']
})
export class HttpStudentComponent implements OnInit {

  students = [];
  private __studentService : StudentService;

  constructor(__studentService:StudentService) {
    this.__studentService = __studentService;
   }

  ngOnInit() {
    console.log(" -- inside nghOnIt");
    this.__studentService.getStudentsFromServer()
      .subscribe(data =>this.students = data);
      console.log(" ---- inside http observable component "+this.students.length);
  }

}
