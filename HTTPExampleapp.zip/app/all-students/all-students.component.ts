import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { Student } from '../student';

@Component({
  selector: 'app-all-students',
  templateUrl: './all-students.component.html',
  styleUrls: ['./all-students.component.css']
})
export class AllStudentsComponent implements OnInit {

  students:Array<Student> = [];
  __service:StudentService;

  constructor(__service:StudentService) { 
    this.__service = __service;
  }

  ngOnInit() {
    this.students = this.__service.getStudentArray();
  }

}//end of class
