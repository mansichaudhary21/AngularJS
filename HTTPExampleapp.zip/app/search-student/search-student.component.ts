import { Component, OnInit } from '@angular/core';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-search-student',
  templateUrl: './search-student.component.html',
  styleUrls: ['./search-student.component.css']
})
export class SearchStudentComponent implements OnInit {
  
  

    dogName : string = "jojo";


  students:Array<Student> = [];
  __service:StudentService;

  constructor(__service:StudentService) { 
    this.__service = __service;
  }

  ngOnInit() {
    this.students = this.__service.getStudentArray();
  }

  doSearchThings(event)
  {
    let searchName = event.target.value;
    console.log(" search name :- "+searchName);

     let isValid = this.__service.getStudentByName(searchName);

     if(isValid)
     {
       console.log(searchName);
     }
     else console.log("student not in the list");
  }
}





