import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-simple-reactive',
  templateUrl: './simple-reactive.component.html',
  styleUrls: ['./simple-reactive.component.css']
})
export class SimpleReactiveComponent implements OnInit {

  constructor() { }

  policyName = new FormControl('noname',[Validators.required]);

  ngOnInit(): void {
  }

  doThings(policy)
  {
    console.log(" ====>> "+policy);
    console.log(" ====>> "+policy.value);
    
  }
}
