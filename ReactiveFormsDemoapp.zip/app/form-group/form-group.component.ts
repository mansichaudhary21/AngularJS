import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup ,Validators} from '@angular/forms';

@Component({
  selector: 'app-form-group',
  templateUrl: './form-group.component.html',
  styleUrls: ['./form-group.component.css']
})
export class FormGroupComponent implements OnInit {

  constructor() { }

  policyForm = new FormGroup(
    {
      policyName : new FormControl('',[Validators.required,Validators.minLength(3)]),
      age : new FormControl('',[Validators.required, Validators.max(60)]),
      panNumber : new FormControl('',[Validators.required, Validators.pattern('([A-Z]){5}([0-9]){4}([A-Z]){1}$')])
    });
  
  ngOnInit(): void {
  }

  get policyName():any{
    return this.policyForm.get("policyName");
  }

  get age():any{
    return this.policyForm.get("age");
  }

  get panNumber():any{
    return this.policyForm.get("panNumber");
  }
}
